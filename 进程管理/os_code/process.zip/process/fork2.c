#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
main()
{
	pid_t val;
	val=fork();
	if (val < 0)
	{
		perror("fork failed!");
		exit(1);
	}
	else if (val > 0)
	{
		while(1)
		{
			printf("|");
		}
	}
	else
	{
		while(1)
		{
			printf("-");
		}
	}
}
