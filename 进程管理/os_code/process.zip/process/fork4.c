#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>
void handle_it();
int status;
main()
{
	signal(SIGCHLD,handle_it);
	if(fork()==0) {
		/*We are the child... */
		execlp("ls", "ls",NULL);
		perror("exec failed");
		exit(1);
	}
	while(1);
}
void handle_it()
{
	wait(&status);
	printf("Exit status of child = %d\n",status);
	exit(0);
}

