#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
int main(int argc,char** argv)
{
	pid_t val;
	int exit_code = 0;

	val=fork();
	if (val < 0)
	{
		fprintf(stderr,"fork failed!\n");
		exit(1);
	}
	else if (val > 0)
	{
		int stat_val;
		pid_t child_pid;
		child_pid = waitpid(val,&stat_val,0);
		printf("Child has finished: PID = %d\n", child_pid);
		if(WIFEXITED(stat_val))
			printf("Child exited with code %d\n", WEXITSTATUS(stat_val));
		else
			printf("Child terminated abnormally\n");
		exit(exit_code);
	}
	else
	{
		
		execlp("ls","ls","-l",NULL);	
	}
}
