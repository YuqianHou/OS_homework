#include <stdio.h>
int main()
{
	system("ls -l");
	printf("Done...\n");
	return 0;
}
