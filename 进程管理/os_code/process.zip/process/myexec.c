#include <stdio.h>
#include <unistd.h>
int main()
{
	int result ;
	result = execlp("ls","ls","-l",0);
	printf("Done...\n");
	return 0;
}
