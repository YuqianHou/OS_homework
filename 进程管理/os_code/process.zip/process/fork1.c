#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
main()
{
	pid_t val;
	printf("PID before fork(): %d \n",(int)getpid());
	val=fork();
	if (val!=0)
	{
		printf("Parent PID: %d\n",(int)getpid());
	}
	else
	{
		printf("Child PID: %d\n",(int)getpid());
	}
}
